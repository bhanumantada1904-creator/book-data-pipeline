# Book Data Pipeline

## Overview

This project implements a complete data pipeline using Python.

The pipeline:

1. Scrapes book data from Books to Scrape.
2. Cleans and converts the scraped fields.
3. Converts GBP prices to INR.
4. Stores the data in a normalized SQLite database.
5. Runs SQL queries against the database.
6. Reads SQL results into pandas DataFrames.
7. Reproduces the SQL JOIN using pandas.merge().

## Data Source

The data source is:

https://books.toscrape.com/

The first 5 catalogue pages were scraped, producing 100 book records
across multiple book categories.

## Technologies

- Python
- requests
- BeautifulSoup
- pandas
- SQLite
- sqlite3
- Google Colab

## Data Cleaning

### Price

The GBP currency symbol was removed and the price was converted to
a float column called `price_gbp`.

### Rating

The text star ratings were converted into integers:

- One = 1
- Two = 2
- Three = 3
- Four = 4
- Five = 5

### Availability

The availability text was converted into the boolean column `in_stock`.

`In stock` is represented as True.

### Missing Values

If numeric fields fail to parse or contain missing values, median
imputation is used for numeric fields such as `price_gbp` and `rating`.

## Currency Conversion

The required fixed project conversion rate is:

**1 GBP = 105.50 INR**

This is a project-defined fixed conversion rate and is not a live
market exchange rate.

The `price_inr` column is calculated using:

`price_inr = price_gbp * 105.50`

## Database Design

The SQLite database contains two normalized tables.

### categories

- category_id INTEGER PRIMARY KEY
- category_name TEXT UNIQUE

### books

- book_id INTEGER PRIMARY KEY
- title TEXT
- price_gbp REAL
- price_inr REAL
- rating INTEGER
- in_stock INTEGER
- category_id INTEGER
- category_id references categories(category_id)

## SQL Queries

Five SQL queries are included covering:

- SELECT
- WHERE
- ORDER BY
- LIMIT
- DISTINCT
- BETWEEN
- JOIN

The query strings and their outputs are saved in the outputs directory.

## Pandas Validation

At least two SQL query results are read back using `pd.read_sql()`.

The SQL JOIN result is independently reproduced using `pandas.merge()`.

Both approaches produce equivalent output.

## Running the Project

Open the notebook in Google Colab and run the cells from top to bottom.

The script creates the SQLite database and output files automatically.